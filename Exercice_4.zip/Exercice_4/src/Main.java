import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String prenom = "Pape";
        char firstCharacter = prenom.charAt(0);
        System.out.println("the string is: " +prenom);
        System.out.println("la premiére caractére est: " +firstCharacter);
        String nom = "Ndiaye";
        char first = nom.charAt(0);
        System.out.println("the string is: " +nom);
        System.out.println("la premiére caractére est: " +first);
        Person P = new Person();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Info de la personne:");
        P.setNom("NDIAYE");
        P.setPrenom("Pape");
        P.setDate_naissance(1998);
        System.out.println("Nom : " + P.getNom());
        System.out.println("Prénom : " + P.getPrenom());
        System.out.println("Annee Naissance : " + P.getDate_naissance());
        System.out.println("Matricule : " + P.getMatricule());
    }
}
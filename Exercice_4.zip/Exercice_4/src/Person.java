import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Person {
    public final int AC = 2023;
    private String nom;
    private String prenom;
    private String matricule;
    private int age;
    private int date_naissance;

    public Person() {
    }

    public Person(String nom, String prenom, String matricule, int age, int date_naissance) {
        this.nom = nom;
        this.prenom = prenom;
        this.matricule = genererMatricule();
        this.age = age;
        this.date_naissance = date_naissance;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getMatricule() {
        return matricule;
    }

    public int getAge() {
        return age;
    }

    public int getDate_naissance() {
        return date_naissance;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setDate_naissance(int date_naissance) {
        this.date_naissance = date_naissance;
    }
    public void saisiP() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Donner le nom");
        nom = scan.nextLine();
        System.out.println("Donner le prenom");
        prenom = scan.nextLine();
    }
    public int age(){

        return AC - date_naissance;
    }
    @Override
    public String toString() {

        return prenom + " " + nom + " " + age() + "ans";
    }

    private String genererMatricule(){
        String mat = "0000" + nom.charAt(0) + prenom.charAt(0);
        char firstCharacter = mat.charAt(0);
        System.out.println("the string is: " +mat);
        System.out.println("la premiére caractére est: " +firstCharacter);
        return mat.toUpperCase();
    }
}
